document.addEventListener('DOMContentLoaded', function() {
    // Admin login functionality
    const adminLoginForm = document.getElementById('adminLoginForm');
    if (adminLoginForm) {
        adminLoginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const errorDiv = document.getElementById('loginError');
            
            // Hardcoded credentials (for demo purposes only)
            if (username === 'admin' && password === 'admin123') {
                // Save login state
                sessionStorage.setItem('adminLoggedIn', 'true');
                // Redirect to admin panel
                window.location.href = 'panel.html';
            } else {
                errorDiv.textContent = 'Invalid username or password';
                errorDiv.classList.remove('d-none');
            }
        });
    }
    
    // Check if admin is logged in when accessing panel
    if (window.location.pathname.includes('panel.html')) {
        const isLoggedIn = sessionStorage.getItem('adminLoggedIn') === 'true';
        if (!isLoggedIn) {
            window.location.href = 'index.html';
        }
    }
    
    // Logout functionality
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            sessionStorage.removeItem('adminLoggedIn');
            window.location.href = 'index.html';
        });
    }
    
    // Sample data for services and projects
    let services = JSON.parse(localStorage.getItem('services')) || [
        {
            id: 1,
            icon: 'fas fa-paint-brush',
            title: 'Web Design',
            description: 'Custom, responsive designs that reflect your brand and engage your audience across all devices.'
        },
        {
            id: 2,
            icon: 'fas fa-code',
            title: 'Web Development',
            description: 'Robust, scalable websites and web applications built with the latest technologies and best practices.'
        },
        {
            id: 3,
            icon: 'fas fa-mobile-alt',
            title: 'Mobile Apps',
            description: 'Native and cross-platform mobile applications designed for optimal performance and user experience.'
        },
        {
            id: 4,
            icon: 'fas fa-chart-line',
            title: 'Digital Marketing',
            description: 'Comprehensive digital marketing strategies to increase your online visibility and drive conversions.'
        }
    ];
    
    let projects = JSON.parse(localStorage.getItem('projects')) || [
        {
            id: 1,
            image: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1374&q=80',
            title: 'E-commerce Website',
            category: 'web',
            description: 'A fully responsive online store with custom checkout process and product management.'
        },
        {
            id: 2,
            image: 'https://images.unsplash.com/photo-1555774698-0b77e0d5fac6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80',
            title: 'Fitness Tracker App',
            category: 'app',
            description: 'A cross-platform mobile application for tracking workouts and nutrition.'
        },
        {
            id: 3,
            image: 'https://images.unsplash.com/photo-1567443024551-f3e3b7b40d08?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80',
            title: 'Coffee Brand Identity',
            category: 'branding',
            description: 'Complete branding package including logo, packaging, and marketing materials.'
        },
        {
            id: 4,
            image: 'https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1469&q=80',
            title: 'Corporate Website',
            category: 'web',
            description: 'Modern corporate website with CMS integration and multilingual support.'
        },
        {
            id: 5,
            image: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80',
            title: 'Travel Planner App',
            category: 'app',
            description: 'Native iOS and Android app for planning and booking travel itineraries.'
        },
        {
            id: 6,
            image: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1374&q=80',
            title: 'Restaurant Branding',
            category: 'branding',
            description: 'Complete visual identity for a gourmet restaurant chain.'
        }
    ];
    
    // Update counts
    document.getElementById('servicesCount').textContent = services.length;
    document.getElementById('projectsCount').textContent = projects.length;
    document.getElementById('teamCount').textContent = 3; // Hardcoded for demo
    
    // Render services table
    function renderServicesTable() {
        const servicesTable = document.getElementById('servicesTable');
        servicesTable.innerHTML = '';
        
        services.forEach(service => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><i class="${service.icon}"></i></td>
                <td>${service.title}</td>
                <td>${service.description.substring(0, 50)}...</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary edit-service" data-id="${service.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger delete-service" data-id="${service.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            servicesTable.appendChild(row);
        });
        
        // Add event listeners to edit buttons
        document.querySelectorAll('.edit-service').forEach(btn => {
            btn.addEventListener('click', function() {
                const serviceId = parseInt(this.getAttribute('data-id'));
                const service = services.find(s => s.id === serviceId);
                
                if (service) {
                    document.getElementById('editServiceId').value = service.id;
                    document.getElementById('editServiceIcon').value = service.icon;
                    document.getElementById('editServiceTitle').value = service.title;
                    document.getElementById('editServiceDescription').value = service.description;
                    
                    const editModal = new bootstrap.Modal(document.getElementById('editServiceModal'));
                    editModal.show();
                }
            });
        });
        
        // Add event listeners to delete buttons
        document.querySelectorAll('.delete-service').forEach(btn => {
            btn.addEventListener('click', function() {
                if (confirm('Are you sure you want to delete this service?')) {
                    const serviceId = parseInt(this.getAttribute('data-id'));
                    services = services.filter(s => s.id !== serviceId);
                    localStorage.setItem('services', JSON.stringify(services));
                    renderServicesTable();
                    renderProjectsTable();
                    document.getElementById('servicesCount').textContent = services.length;
                }
            });
        });
    }
    
    // Render projects table
    function renderProjectsTable() {
        const projectsTable = document.getElementById('projectsTable');
        projectsTable.innerHTML = '';
        
        projects.forEach(project => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><img src="${project.image}" alt="${project.title}" width="50" height="50" class="rounded"></td>
                <td>${project.title}</td>
                <td>${project.category === 'web' ? 'Web Design' : project.category === 'app' ? 'Mobile Apps' : 'Branding'}</td>
                <td>${project.description.substring(0, 50)}...</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary edit-project" data-id="${project.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger delete-project" data-id="${project.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            projectsTable.appendChild(row);
        });
        
        // Add event listeners to edit buttons
        document.querySelectorAll('.edit-project').forEach(btn => {
            btn.addEventListener('click', function() {
                const projectId = parseInt(this.getAttribute('data-id'));
                const project = projects.find(p => p.id === projectId);
                
                if (project) {
                    document.getElementById('editProjectId').value = project.id;
                    document.getElementById('editProjectImage').value = project.image;
                    document.getElementById('editProjectTitle').value = project.title;
                    document.getElementById('editProjectCategory').value = project.category;
                    document.getElementById('editProjectDescription').value = project.description;
                    
                    const editModal = new bootstrap.Modal(document.getElementById('editProjectModal'));
                    editModal.show();
                }
            });
        });
        
        // Add event listeners to delete buttons
        document.querySelectorAll('.delete-project').forEach(btn => {
            btn.addEventListener('click', function() {
                if (confirm('Are you sure you want to delete this project?')) {
                    const projectId = parseInt(this.getAttribute('data-id'));
                    projects = projects.filter(p => p.id !== projectId);
                    localStorage.setItem('projects', JSON.stringify(projects));
                    renderProjectsTable();
                    document.getElementById('projectsCount').textContent = projects.length;
                }
            });
        });
    }
    
    // Save new service
    const saveServiceBtn = document.getElementById('saveServiceBtn');
    if (saveServiceBtn) {
        saveServiceBtn.addEventListener('click', function() {
            const icon = document.getElementById('serviceIcon').value;
            const title = document.getElementById('serviceTitle').value;
            const description = document.getElementById('serviceDescription').value;
            
            if (icon && title && description) {
                const newId = services.length > 0 ? Math.max(...services.map(s => s.id)) + 1 : 1;
                const newService = {
                    id: newId,
                    icon: icon,
                    title: title,
                    description: description
                };
                
                services.push(newService);
                localStorage.setItem('services', JSON.stringify(services));
                
                // Close modal
                const addModal = bootstrap.Modal.getInstance(document.getElementById('addServiceModal'));
                addModal.hide();
                
                // Reset form
                document.getElementById('addServiceForm').reset();
                
                // Update table and count
                renderServicesTable();
                document.getElementById('servicesCount').textContent = services.length;
            }
        });
    }
    
    // Update existing service
    const updateServiceBtn = document.getElementById('updateServiceBtn');
    if (updateServiceBtn) {
        updateServiceBtn.addEventListener('click', function() {
            const id = parseInt(document.getElementById('editServiceId').value);
            const icon = document.getElementById('editServiceIcon').value;
            const title = document.getElementById('editServiceTitle').value;
            const description = document.getElementById('editServiceDescription').value;
            
            if (id && icon && title && description) {
                const serviceIndex = services.findIndex(s => s.id === id);
                if (serviceIndex !== -1) {
                    services[serviceIndex] = {
                        id: id,
                        icon: icon,
                        title: title,
                        description: description
                    };
                    
                    localStorage.setItem('services', JSON.stringify(services));
                    
                    // Close modal
                    const editModal = bootstrap.Modal.getInstance(document.getElementById('editServiceModal'));
                    editModal.hide();
                    
                    // Update table
                    renderServicesTable();
                }
            }
        });
    }
    
    // Save new project
    const saveProjectBtn = document.getElementById('saveProjectBtn');
    if (saveProjectBtn) {
        saveProjectBtn.addEventListener('click', function() {
            const image = document.getElementById('projectImage').value;
            const title = document.getElementById('projectTitle').value;
            const category = document.getElementById('projectCategory').value;
            const description = document.getElementById('projectDescription').value;
            
            if (image && title && category && description) {
                const newId = projects.length > 0 ? Math.max(...projects.map(p => p.id)) + 1 : 1;
                const newProject = {
                    id: newId,
                    image: image,
                    title: title,
                    category: category,
                    description: description
                };
                
                projects.push(newProject);
                localStorage.setItem('projects', JSON.stringify(projects));
                
                // Close modal
                const addModal = bootstrap.Modal.getInstance(document.getElementById('addProjectModal'));
                addModal.hide();
                
                // Reset form
                document.getElementById('addProjectForm').reset();
                
                // Update table and count
                renderProjectsTable();
                document.getElementById('projectsCount').textContent = projects.length;
            }
        });
    }
    
    // Update existing project
    const updateProjectBtn = document.getElementById('updateProjectBtn');
    if (updateProjectBtn) {
        updateProjectBtn.addEventListener('click', function() {
            const id = parseInt(document.getElementById('editProjectId').value);
            const image = document.getElementById('editProjectImage').value;
            const title = document.getElementById('editProjectTitle').value;
            const category = document.getElementById('editProjectCategory').value;
            const description = document.getElementById('editProjectDescription').value;
            
            if (id && image && title && category && description) {
                const projectIndex = projects.findIndex(p => p.id === id);
                if (projectIndex !== -1) {
                    projects[projectIndex] = {
                        id: id,
                        image: image,
                        title: title,
                        category: category,
                        description: description
                    };
                    
                    localStorage.setItem('projects', JSON.stringify(projects));
                    
                    // Close modal
                    const editModal = bootstrap.Modal.getInstance(document.getElementById('editProjectModal'));
                    editModal.hide();
                    
                    // Update table
                    renderProjectsTable();
                }
            }
        });
    }
    
    // Initialize tables if on admin panel
    if (window.location.pathname.includes('panel.html')) {
        renderServicesTable();
        renderProjectsTable();
    }
});